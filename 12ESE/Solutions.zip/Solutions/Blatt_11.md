![_2022-03-03-16-18-01](_resources/_2022-03-03-16-18-01.png)

# 1
![_2022-03-03-16-18-54](_resources/_2022-03-03-16-18-54.png)

# 2
> Klausur wahrscheinlich nur: ADC Quantisierungserror, hier z.B. Clockfrequenz bestimmen oder nen I2C Datengraph malen. Vorstellbar das sowas drankommt. Beschreibe 1 Busprotokoll, was schreiben oder Skizee, dass man 2 Buse hat usw.
> Vielleicht auch Aufgabe, wie man Energie sparen kann und man braucht nicht so viel Hintergrundwissen wissen
> Bandpassfilter und Fourier Transformation unwahrscheinlich

![_2022-03-03-16-25-42](_resources/_2022-03-03-16-25-42.png)

## a)
![_2022-03-03-16-30-24](_resources/_2022-03-03-16-30-24.png)
- innertial measurement unit **🠒** Trägheitsmessung
- 9dof **🠒** 9 Dimensions of freedom

![_2022-03-03-16-36-16](_resources/_2022-03-03-16-36-16.png)
- die eine Adresse das letzte Bit ist ein 0 und beim anderen ne 1

![_2022-03-03-16-36-31](_resources/_2022-03-03-16-36-31.png)

![_2022-03-03-17-08-59](_resources/_2022-03-03-17-08-59.png)
- Modul Microcontroller ist unten links
- ground und vda ("supply voltage") oben, 2 Datenleitungen sind rechts
- An Datenleitung und Clock Slaves IMU 1 und 2 verbunden
- Dadurch, dass wir dem einen das letzte Bit auf 0 setze müssen und dem anderen auf 1, haben wir die auch schon kodiert mit unseren richtigen Adressen
- Die Pullup Widerstände dienen einfach nur, dass unser Signal stabil ist, dass wenn wir nichts anlegen, dass wenn wir nichts anlegen es einfach high ist
- bei AD0 könnte man es einfach verbinden, da braucht man nicht umgedingt Pullup und Pulldown Widerstände, aber schadet auch nicht

## b)
![_2022-03-03-17-10-29](_resources/_2022-03-03-17-10-29.png)
- IMU hat einen FIFO, wenn man im Datenblatt schaut
- uC Microcontroller

![_2022-03-03-17-12-41](_resources/_2022-03-03-17-12-41.png)
- Interrupt driven **🠒** Busdesign anpassen, dafür brauchen wir extra Kabel

![_2022-03-03-17-25-16](_resources/_2022-03-03-17-25-16.png)
- $Pin_{12}$: Wenn wir neues Signal haben, dann senden wir es über dieses Kabel "$INT_1$"
- wenn hier (2 Kreis links unten) eine Änderung auftritt, wissen wir unser Sensor hat ein neues Signal empfangen oder irgendwas neues gemessen, jetzt müssen wir es auswerten und lesen lassen

## c)
![_2022-03-03-17-30-18](_resources/_2022-03-03-17-30-18.png)
- im 50Hz Abstand wollen wir die Daten haben, bedeutet wie schnell muss dann unsere Clock vom Bussystem schlagen, sodass wir noch wirklich alle Daten nach 50Hz haben
- SPI kann schneller mit 20MHz dadurch das wir nicht immer die Adresse mitschicken müssen
- Beschleinigung und Winkelgeschwindigkeit, jeder dieser Werte hat eine Länge von 2Byte
- $6 \cdot 16 = 96$

![_2022-03-03-17-42-27](_resources/_2022-03-03-17-42-27.png)
- nochmal schauen wie genau I2C funktioniert
- Bild aus Datenblatt, wie Ablauf von I2C
- zuerst senden wir Startcondition über den Master, danach Adresse vom Slave mit write, das muss der Slave, der angesprochen wird acknowledgen. Danach können wir das Register senden. Danach können wir das Register senden, das muss auch wieder der Slave acknowledgen. Startcondition, Slave Adresse ansprechen mit Read, Acknowledgen, dann sendet der Slave die Daten, das ganze hört auf wenn wir Notacknowledgement haben. P Stopcondition
- senden Registeradressen und Slaveadressen immer hin und her

![_2022-03-04-04-04-47](_resources/_2022-03-04-04-04-47.png)
- die Bytes müssen wir auch dazuzählen in unserer Rechnung
- **roter Strich:** 27 Bits bevor man irgendwelche Daten senden kann. Dabei sind Stardconditions noch nicht mitgezählt, denn bei Startconditions kann man repeated Startconditions machen oder einzelne Stardconditions
- wir müssen 2 mal für beide IMU's die 12 Byte senden und wir haben immer dieses 27 Bits, also alles vor den Daten und dann die 9 Bits Daten + Acknowledgment **🠒** d.h. wir müssen 864 Bits senden pro einmal Daten auslesen
- Wenn wir das mit den 1400 kHz maximale Frequenz machen, dann kämen wir auf 2.16ms, die wir allgemein brauchen um einmal so ein Datensatz auszulesen
- 50Hz sind jede 20ms
- man sieht jetzt schon, dass es ziemlich knapp wird, bevor wir nochmal genau ausrechnen würden, was wir den für eine Frequenz als minimal brauchen würden
**🠒** schauen, ob es andere Möglichkeit gibt, wie wir das ganze vielleicht schneller vollstrecken können

![_2022-03-04-04-25-18](_resources/_2022-03-04-04-25-18.png)

![_2022-03-04-04-40-13](_resources/_2022-03-04-04-40-13.png)
- Anfangssequenz vom Singleread, aber im Gegensatz zu Singleread muss man danahc das ganze vom Anfang nicht nochmal machen, man kann Daten direkt nochmal schicken. Man erhält Verbindung aufrecht
- nimmt automatisch nächstes Register
- schauen, liegen Daten überhaupt in den Registern, die nebeneinander liegen
  - Adressen für Beschleinigung und Winkelgeschwindigkeit liegen quasi relativ nah beianander. Haben Register 41 und 42, die wir eigentlich nicht lesen müssen
- lesen nicht 12 Bytes wie vorher, sondern 14 Bytes, da wir eben die Temperatursensorwerte mitnehmen
  - 9 Bits **🠒**  8 Bits von den Daten und das eine Bit für das Acknowledgment
  - muss man 2 mal machen, da wir 2 Sensoren haben
  - wenn wir das machen, dann kommen wir auf 306 Bits
  - davor hatten wir irgendwas mit 800
- wie lange würde so ein Datentransfer dauern: maximale Frequenz nehmen, die wir mit I2C haben können, dann kämen wir auf $765\mu s$
  - $\displaystyle\frac{1}{\frac{times}{s}} \cdot times=\underbrace{\frac{s}{times}}_{\text{delay between events}} \cdot times = s$
  - $50Hz$ **🠒** delay of $\displaystyle\frac{1}{50 \frac{1}{s}} = \frac{1}{50}s = 0.02s = 20ms$
- $765\mu s$ sind $0.765ms$ < $20ms$ bzw. $10ms$ ^_^

![_2022-03-04-04-54-46](_resources/_2022-03-04-04-54-46.png)
- jetzt wollen wir minimale Frequnez ausrechnen, die wir bräuchten

![_2022-03-04-05-40-26](_resources/_2022-03-04-05-40-26.png)
- "man will, dass Daten alle 50Hz komplett gesampelt werden, dazu müssen die Daten spätestens nach nach 20ms da sein, zu Sicherheit alle 10ms"
- "30.6kHz ist die minimale Frequenz, die man mindestens braucht damit man unter 10ms kommt, wenn man 306 Byte innerhalb dieser Zeit verschicken will"
- unser IMU kann nur `100kHz` und `400kHz`
- es würd locker ausreichen, wenn wir Standard Mode 100kHz nehmen und nicht den fast mode mit 400kHz

## d)
![_2022-03-04-07-51-18](_resources/_2022-03-04-07-51-18.png)
- wenn DR=DataRead True ist, also die Verbindung von unserem $Pin_{12}$ zu unserem Interrupt-Signal, dann setzen wir das auf True und stoppend wieder???

![_2022-03-04-07-51-51](_resources/_2022-03-04-07-51-51.png)

![_2022-03-04-07-52-06](_resources/_2022-03-04-07-52-06.png)

![_2022-03-04-07-52-21](_resources/_2022-03-04-07-52-21.png)

![_2022-03-04-07-52-37](_resources/_2022-03-04-07-52-37.png)
- erstmal schauen, was das Register ist ab wo man lesen muss **🠒**  Register 3b

![_2022-03-04-07-53-17](_resources/_2022-03-04-07-53-17.png)
- Beschleinigungswert, x-wert und man fängt bei high an
  - wir hatten 16 Bit Datenlänger, bedeutet, wir unterteilen diese 16 Bit in 2 mal 8 Bit, bedeutet wir haben hier immer einen Highteil, das ist der vordere Teil unsrer Daten
    - wenn man weiterschaut, die nächsten wären dann der low, dann kommt y, dann kommt z usw.
- wir lesen zuerst unsere 8Bit high, diese 8 mal nach links shiften

## e)
![_2022-03-04-07-53-56](_resources/_2022-03-04-07-53-56.png)

![_2022-03-04-07-54-08](_resources/_2022-03-04-07-54-08.png)
- ist etwas versetzt
- 68 in binär dargestellt

```
0x68 ❯ 104
64+32+8 ❯ 104
```
- Write ist 0, acknowledgement ist auch immer 0, NACK ist 1
- danach muss man etwas warten und sendet danach die Registeradresse, dieser `ACCEL_XOUT_H`-Wert ab dem wir lesen wollen, binär codiert
- IMU1_DR wurde 1, bedeutet er hat Daten, hat es uns somit mitgeteilt und somit fangen wir an zu lesen

## f)
![_2022-03-04-07-54-19](_resources/_2022-03-04-07-54-19.png)

![_2022-03-04-07-54-43](_resources/_2022-03-04-07-54-43.png)

![_2022-03-04-13-32-16](_resources/_2022-03-04-13-32-16.png)

![_2022-03-04-07-55-21](_resources/_2022-03-04-07-55-21.png)

![_2022-03-04-07-55-34](_resources/_2022-03-04-07-55-34.png)

![_2022-03-04-07-56-40](_resources/_2022-03-04-07-56-40.png)

![_2022-03-04-07-56-57](_resources/_2022-03-04-07-56-57.png)

![_2022-03-04-07-57-20](_resources/_2022-03-04-07-57-20.png)

![_2022-03-04-07-57-43](_resources/_2022-03-04-07-57-43.png)

## Datenblatt durchgehen
![_2022-03-04-17-27-44](_resources/_2022-03-04-17-27-44.png)

![_2022-03-04-17-08-01](_resources/_2022-03-04-17-08-01.png)

![_2022-03-04-17-11-36](_resources/_2022-03-04-17-11-36.png)

![_2022-03-04-17-19-06](_resources/_2022-03-04-17-19-06.png)

![_2022-03-04-17-24-23](_resources/_2022-03-04-17-24-23.png)

![_2022-03-04-17-25-24](_resources/_2022-03-04-17-25-24.png)

![_2022-03-04-17-29-25](_resources/_2022-03-04-17-29-25.png)

![_2022-03-04-17-31-59](_resources/_2022-03-04-17-31-59.png)
