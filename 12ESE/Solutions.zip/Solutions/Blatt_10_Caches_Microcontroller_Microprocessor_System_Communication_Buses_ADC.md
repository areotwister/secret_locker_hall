![_2022-03-01-04-33-06](_resources/_2022-03-01-04-33-06.png)

# 1
![_2022-03-01-04-33-43](_resources/_2022-03-01-04-33-43.png)

## a)
![_2022-03-01-04-36-45](_resources/_2022-03-01-04-36-45.png)

![_2022-03-01-05-24-53](_resources/_2022-03-01-05-24-53.png)
- last recently used = LRU
- erster Eintrag ist ein Miss, denn man muss diese Adresse zuerst einmal in den Cache schreiben
- 00000 ist da auch noch drin, durch " dargestellt
- so weiter bis 01011, noch nicht im cache vorhanden, Frage welchen dieser Einträge wir verdrängen **🠒** LRU, dass was am weitesten weg ist, cache block 3 als letztes benutzt, dann cache block 4, 2, 1, also Eintrag aus cacheblock 1 verdrängen **🠒** statt 00000 haben wir da jetzt stehen 01011 (ist auch wieder ein Miss, da wir etwas neues in den Cache schreiben mussten)
- dooferweise nach 01011 00000, die man gerade verdrängt hat, nicht mehr im Cache drin, wenn man letzte Einträge anschaut, Cacheblock zuletzt nicht benutzt ist jetzt Cacheblock 2, verdrängen 11111
- wieder blöd gelaufen, gerade 11111 verdrängt, jetzt braucht man sie wieder, Cacheblock 4 diesmal zuletzt nicht mehr benutzt (warum nicht Cacheblock 3 **🠒** weil wir den hier nochmal nach Cacheblock 4 aufgerufen haben)

![_2022-03-01-05-25-37](_resources/_2022-03-01-05-25-37.png)
- 10, hier in Cacheblock 3 schreiben, weil letzer Block längsten nicht mehr vewendet ist Cacheblock 3

![_2022-03-01-05-28-01](_resources/_2022-03-01-05-28-01.png)

![_2022-03-01-05-30-58](_resources/_2022-03-01-05-30-58.png)
- am längsten nicht benutzter Cacheblock ist Cacheblock 1
- ganze am Schluss mit 00000 ein Cachehit
- Misses sind immer fett, Hits immer kursiv

## b)
![_2022-03-01-05-31-41](_resources/_2022-03-01-05-31-41.png)
- LFU: da schaut man wie häufig irgenwas benutzt wurde
  - wenn gleich oft benutzt, dann man den ältesten Eintrag (LRU)

![_2022-03-02-10-51-06](_resources/_2022-03-02-10-51-06.png)
- erste 4 kann man direkt eintragen, da sie alle unterschiedlich sind
- oben counter, wie oft welcher **Cache Block** benutzt wurde
- der Counter geht auch hoch, wenn ein Cache Hit war
- bei 01011 benutzt man LRU, da bei LFU 3 mal 1 ist
  - löschen, aber wir haben es bisher auch nur einmal benutzt
  - beim zweiten 01011 erhöht man auf 2
- nur 2 Hits **🠒** schlechter als nur LRU

![_2022-03-02-10-51-39](_resources/_2022-03-02-10-51-39.png)

![_2022-03-02-10-52-39](_resources/_2022-03-02-10-52-39.png)
- im Gegensatzu zu LRU, hat sich bei LFU nur der rote Teil geändert

## c)
![_2022-03-02-10-54-41](_resources/_2022-03-02-10-54-41.png)
- the least significant bits

![_2022-03-02-10-56-16](_resources/_2022-03-02-10-56-16.png)

![_2022-03-02-13-58-27](_resources/_2022-03-02-13-58-27.png)
- verdrängen 11111 gleich wieder für 10011

![_2022-03-02-13-58-48](_resources/_2022-03-02-13-58-48.png)
- war ein bischen besser

## d)
![_2022-03-02-17-38-56](_resources/_2022-03-02-17-38-56.png)
- nicht universal für Prozessor gültig

![_2022-03-02-17-41-34](_resources/_2022-03-02-17-41-34.png)
- wenn nur Zahlen mit 11 als least siqnfikant bit, dann hätte man nur in einen Cacheblock geschrieben **🠒** ineffizient

# 2
> Klausur 120 Punkte für 120 Minuten

## a)
![_2022-03-02-17-47-13](_resources/_2022-03-02-17-47-13.png)
- Microcontroller hat mehr Interfaces und Memory, hat ADC's und DC's direkt mit drauf **🠒** ist System on chip
- Microprozessor ist einfach nur eine Rechnereinheit, wo man extern noch Memory hinzuschalten muss

![_2022-03-02-17-48-46](_resources/_2022-03-02-17-48-46.png)

## b)
![_2022-03-02-17-58-16](_resources/_2022-03-02-17-58-16.png)
- also Protokolle

### UART
![_2022-03-02-17-58-33](_resources/_2022-03-02-17-58-33.png)
- r = receiving, t for transmission
- wichtig, dass rx mit tx und tx mit rx verbunden werden muss, da wenn man was sendet, dann empfänger der andere das und vice versa
- a in UART steht für asynchron **🠒** man hat keine clock die mitläuft, aber die Geschwingikeit / baudrate muss vorher abgeklärt sein unter beiden

![_2022-03-02-18-04-11](_resources/_2022-03-02-18-04-11.png)
- wenn TX von high auf low geht, dann bedeutet das den start der Übertragung, wenns dann länger Zeit high ist, Bitsequenz, die länger Zeit 1 ist, dann hat die Übertragung aufgehört

### I2C
![_2022-03-02-18-05-23](_resources/_2022-03-02-18-05-23.png)
- synchrones Protokoll **🠒** clock
- Master-Slave System: haben ein Modul den Master, der initiert die clock, muss sagen in welcher Geschwindigkeit die Übertragung stattfindet, nur der master kann eine trasnmission initiaten, bedeutet auch wenn keine Sendung gerade unterwegs ist, dann ist auch die clock 0. Bedeutet wir wissen es passiert gerade was, wenn die clock überhaupt gerade taktet

![_2022-03-02-18-16-58](_resources/_2022-03-02-18-16-58.png)
- hinter einem IC2 können ganz viele slaves sein
- haben nur eine Datenlinie, bedeutet in dieser Datenlinie müssen wir zum einen welchen Slave wir betrachten wollen, man sendet Adresse des Slave mit, dann sendet man mit ob man lesen oder schreiben will, dann acklowledgement und dann unsere Daten

### SPI
![_2022-03-02-18-17-31](_resources/_2022-03-02-18-17-31.png)
- wenn wir schneller Daten übertragen wollen
- sck wieder clock, die über Master geschalten wird

![_2022-03-02-21-47-15](_resources/_2022-03-02-21-47-15.png)
- einmal senden wir vom Master Output, was der Slave Input ist, aber wir könne auch vom Slave senden, also Slave Output, der auf Master Input geht
- man kann am SPI mehere Slaves haben, letzte Linie sagt, welcher Slave selected wird
  - wenn wir mehrere Slaves haben, haben wir mehrere Linien
- diese letzte Linie ist normalerweise high und der slave den wir ansprechen wollen kriegt dann ein low Signal

> gibt noch andere wie PWM, OneWire

## c)
![_2022-03-02-21-48-59](_resources/_2022-03-02-21-48-59.png)

![_2022-03-02-22-22-08](_resources/_2022-03-02-22-22-08.png)
- von 1Hz jedes Sekunde zu jede Minute
- FIFO bedeutet immer so einen kleinen Speicher
  - erst wenn Speicher voll ist auf Mikrocontroller übertragen
  - sampling rate dadurch nochmal deutlich runtergeschraubt, aber Frage wie genau direkt wir Daten in Datebank haben wollen und nciht erst vor 10 Minuten
- kann auch zwischen sampling Sachen in Sleep Mode gehen. Wenn man langsamer sampelt lohnt es sich Microcontroller in den Sleep reinzumachen, vor allem wen wir das Interrupt-driven machen und nicht die ganze Zeit gucken beim Sensor
- die größten Sachen: Interrupt driven und immer nur wenn sich was ändert und speichern und erst hochladen, wenn genügend Daten da sind hochladen

# 3
> Dinge in Aufgabe drin, die nicht in Vorlesung waren

![_2022-03-03-04-04-25](_resources/_2022-03-03-04-04-25.png)
- was Sensor zurückgibt ist diese Funktion, y = hearth rate im Sinus, wenn Herzfrequenz schneller, dann ist auch Frequenz vom Sinus deutlich schneller
- A/D Converter finden mit dem das gut geht
- Nyquist-Shannon benutzt man um die Abtastrate zu finden von Systemen, das man auch wirklich gute Ergebnisse hat

## a)
![_2022-03-03-04-12-08](_resources/_2022-03-03-04-12-08.png)
- wir bekommen die Abtastrate, gitl für ein Bandsignal, bedeutet ok wir wissen unsere Frequenz liegt in irgendeinem bestimmen Band, z.B. 1 Hz bis 4Hz irgendwo da drin... Wie muss dann unsere Sampling Frequnez sein. Die muss größer sein als 2 mal das Band. In dem Fall z.B. hier mit Band 1Hz bis 4Hz, Band ist dann 3Hz breit, also muss unsere Abtastfrequenz größer als 6Hz sein
  - das ist so nen bisschen nen Richtwert

![_2022-03-03-04-13-27](_resources/_2022-03-03-04-13-27.png)

## b)
![_2022-03-03-04-15-15](_resources/_2022-03-03-04-15-15.png)
- extra Hardware hinzufügen, damit Nyquist Shannon gut geht
- Sensor kann nur in bestimmter Frequenz, Herzfrequenz ist begrenzt
- Wenn wir ganz viel Noise haben auf unserem Signal, könnte man da auch mitmessen **🠒** was für Hardware nimmt man um besseres Signal zu haben **🠒** Filter anwenden
- Herzfrequenz ist relativ langsame Frequenz, dann wird auf jeden Fall ein Tiefpassfilter helfen, besser ist noch ein bisschen der Bandpassfilter
- hohe Frequenzen wollen wir auf jeden Fall einfach rausfiltern
- Abbildung links: haben 2 RC-Glieder, High-Pass und Low-Pass, bedeutet beim High-Pass gehen die hohen Frequenzen durch, beim Low-Pass gehen die tiefen Frequenzen durch und je nachdem müssen wir unser R und C so wählen, dass wir eben einen richtigen Bereich auswählen, den wir haben wollen
- Abbildung rechts: wie ein Bandpassfilter die Frequenzen durchlässt
![_2022-03-03-04-48-49](_resources/_2022-03-03-04-48-49.png)
- diese und diese Frequenz werden durchgeleitet und alles andere wird bestmöglich rausgefiltert
- wenn wir es uns nun im Menschen anschauen, dann haben wir ca. 45-240 $\frac{beats}{minute}$, unser Minumum Freuqenz, die sich ergibt ist 0.75Hz und 4Hz

## c)
![_2022-03-03-04-15-39](_resources/_2022-03-03-04-15-39.png)
- nun geht es um ADC

![_2022-03-03-04-16-29](_resources/_2022-03-03-04-16-29.png)
- Quantisierungsfehler: wenn wir Signal haben und das mit dem ADC quantisieren wollen, dann haben wir zum einen ein Problem mit der Zeit, dass es Zeitdiskret ist, als auch Wertdiskret. Zeitdiskret ist die X-Achse, denn wir können immer nur in einer bestimmten Zeitspannae es überhaupt messen (t eingzeichnet). Wertdiskret: wir können auch auf Y-Achse nur bestimmte Zahlen abbilden, also wenn wir... wen hier (rechte Zeichnung) einfach nur unser Signal ist, dann kann es sein, dass wir eben nur hier diese Zahl abbilden können und diese Zahl (2 horinzontale Linien) abbilden können (die z-änliche Linie rechts eingezeichnet), aber nie dazwischen irgendwie was. Und hier dieses Wertdiskrete, dass wir nicht alle Zahlen überhaupt abbilden können, das ist unser Quanitisierungserror
  - jetzt ist die Frage wie berechnen wir den **🠒** wir müssen schauen welche Zahlen wir abbilden können und welche nicht, also wieviele Zahlen. Und wir habe an hier gegeben unsere Referenzspannung, also können wir von 0V bis 3.3V die Werte abbilden und wir haben dafür 12 Bits zur Verfügung, bedeutet wir können $2^{12}$ Zahlen oder Werte darstellen **🠒** bedeutet für unseren Quantisierungserror, wir haben 3.3V, die können wir mit $2^{12}$ Bits darstellen, also ist unser Quantisierungserror einfach $\frac{3.3V}{2^{12}}$, was genau dieser Abstand (rechts Zeichnung). $0.8mV$ ist schon ziemlich gut, da wir hier auch nur eigentlich die Frequenz berechnen wollen
- ist eine Gute Wahl, sogar schon fast ein kleines bisschen zu gut
  - man könnte es natürlich noch etwas verbessern, wir sehen, dass unser Signal höchstens hier bis $2.8V$ geht, also wir müssen garnicht bis $3.3V$ gehen, wir können auch $2.9V$ nehmen als höchste Spannung. Manche ADC's, bei denen kann man das einstellen, bei manchen nicht, manche ADC's laufen nur mit $3.3V$ oder $5V$
  - dieser Quantisierungseror ist ziemlich gering, wir müssen eigentlich nur die Frequenz wissen, daher können wir da auch etwas runtergehen mit den Bits

![_2022-03-03-04-16-48](_resources/_2022-03-03-04-16-48.png)

## d)
![_2022-03-03-04-17-55](_resources/_2022-03-03-04-17-55.png)
- das Originalsignal ist das blaue
- verschiedene ADC Settings 4Hz und 20Hz **🠒**  schon relativ genau auf 20Hz bezogen

![_2022-03-03-04-17-19](_resources/_2022-03-03-04-17-19.png)
- das ist das was wir in der a) schon mit Nyquist Shannon herausgefunden haben **🠒** zwischen 0.75Hz und 4Hz ist die normale Herzfrequenz eines Menschen, bei 0Hz ist er tot **🠒** ca. Samplingsfrequenz von 8Hz **🠒**  bedeutet 4Hz ist zu klein, nicht ausreichend und 20Hz ist auf jeden Fall ausreichend, vielleicht sogar etwas zu gut dafür

![_2022-03-03-04-17-31](_resources/_2022-03-03-04-17-31.png)

## e)
![_2022-03-03-04-18-55](_resources/_2022-03-03-04-18-55.png)
- **FFT extrahiert aus einem Signal die Frequenzanteile**
- Abbilung oben: Frequnez die etwas langasmer ist und darin haben wir eine deutlich höhere Frequenz. Und FFT schaut, was hat es für Frequenzanteile
  - wenn man das bei diesem Beispiel macht, dann bekommt man untere Abbildung **🠒** Peak bei 1Hz, das ist die langsame Frequenu und Peak bei 10Hz, das ist das schnellere Frequenz
- wenn wir FFT anwenden, dann können wir aus unerem Signal die Frequenz ableiten **🠒**  genau das was wir wollen
- wieso da noch die 60 **🠒**  weil Hz $\frac{1}{s}$ ist, aber bpm bedeutet beats per minute, also $60s$ für eine Minute. Deswegen haben wir hier die $60$

## f)
![_2022-03-03-04-19-50](_resources/_2022-03-03-04-19-50.png)
- wenn wir hier unser Signal haben, uns reicht ja wirklich nur die Frequenz, also hätten wir auch einfach einen Comporator nehmen können, der immer, wenn es über $1.4V$ war. Immer wenn es über $1.4V$ geht, messen wir die Zeit. Wir messen die Zeit hier, hier und hier (vertikale Striche in der Zeichnung) und messen dann hier den Abstand und unsere Frequenz ist dann einfach $f=\frac{1}{T}$

![_2022-03-03-04-20-48](_resources/_2022-03-03-04-20-48.png)
