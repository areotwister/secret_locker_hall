![_2022-02-24-09-07-03](_resources/_2022-02-24-09-07-03.png)

# 1
![_2022-02-24-15-55-44](_resources/_2022-02-24-15-55-44.png)
- weak liveness: das man keinen Deadlock hat
- weak_liveness: man kann Loop machen, dann kommt man nicht in Deadlock rein, aber sobald man Marke hinten erreicht hat, kann man kein Event mehr feuern, man ist im Deadlock
  - weak_liveness wäre, man hätte da vorne noch eine Markierung. Man war einmal in dieser Marking, aber kommt danach nie wieder rein. Bedeutet man landet trotzdem nicht in einem Deadlock, aber erreicht nicht mehr alle Markings
- strong_liveness (in blau umkreist): man kann jede Markierung von jeder anderen erreichen

![_2022-02-24-16-06-48](_resources/_2022-02-24-16-06-48.png)

- Deadlock gefunden -> erfüllt nicht weak_liveness

![_2022-02-24-16-11-01](_resources/_2022-02-24-16-11-01.png)

# 2
## a)
![_2022-02-24-16-15-14](_resources/_2022-02-24-16-15-14.png)

![_2022-02-24-16-17-07](_resources/_2022-02-24-16-17-07.png)

![_2022-02-24-16-32-31](_resources/_2022-02-24-16-32-31.png)
- kleine Loop die immer wieder auf sich selbst zeigt, haben wir rechts nicht
- simple net <=> wenn wir die gleichen Preconditions haben und die gleichen Postconditions von einem Event, dann muss x = y sein
  - im Petrinet schauen, ob irgendwo Transition, die irgendwo gleiche Post- und Preconditions hat -> finden wir nicht
- closed with right to firing und inverse firing: wir können jede Condition und jede Transition, egal ob wir jetzt feuern oder zurück einfach die Pfeile umdrehen, erreichen, genauso bei den Markings
  - oben Beispiel wenn man es nicht könnte
- letzte Kriterium: sagt es muss deadlockfrei sein. Wenn man sich Erreichbarkeitsgraph anschaut, dann sieht man, man hat hier nirgendwo einen Pfeil der da komplett rausgeht, auf irgendein Marking zeigt, wo wir nirgendwo hinkommen, sondern man hat hier zwei Kreise
-> alle Kriterien erfüllt, es ist wirklcih ein Condition-Event Netz
  - sogar mit strong-liveness (wenn man auf Erreichbarkeitsgraph schaut)

## b)
![_2022-02-24-16-35-02](_resources/_2022-02-24-16-35-02.png)

![_2022-02-24-16-38-51](_resources/_2022-02-24-16-38-51.png)
- oben hat man bei Edit die ganzen places und Transitions, dann kann Pfeile, also die Flow Relations malen

![_2022-02-24-16-43-45](_resources/_2022-02-24-16-43-45.png)
- Ampelschaltung von letztem Übungsblatt
- man kann nicht Rg1 und Rg2 gleichzeitig feuern, sonst würde man ja auch in G1 und G2 gleichzeitig landen, was man ja im letzten Übungsblatt ausschließen sollte

# 3
## a)
![_2022-02-24-16-47-23](_resources/_2022-02-24-16-47-23.png)

![_2022-02-24-16-49-35](_resources/_2022-02-24-16-49-35.png)

![_2022-02-24-16-59-14](_resources/_2022-02-24-16-59-14.png)

![_2022-02-24-17-01-11](_resources/_2022-02-24-17-01-11.png)

![_2022-02-24-17-16-28](_resources/_2022-02-24-17-16-28.png)

## b)
![_2022-02-24-17-03-40](_resources/_2022-02-24-17-03-40.png)
- Deadlockfrei prüfen
- gibt Punkte, wo man keine Transition mehr feuern kann, weil man keine Getränke mehr hat
- mit diesem Modell kriegt man auf jeden Fall einen Deadlock mit rein

![_2022-02-24-17-05-32](_resources/_2022-02-24-17-05-32.png)
- wie kann man Deadlock vermeiden:
  - Button um Geld wieder zurückgeben zu können, kommt nie in Deadlock, da man immer eine Transition feuern kann

![_2022-02-24-17-17-03](_resources/_2022-02-24-17-17-03.png)

![_2022-02-24-17-17-42](_resources/_2022-02-24-17-17-42.png)

## c)
![_2022-02-24-17-11-36](_resources/_2022-02-24-17-11-36.png)
- informieren, dass Getränke leer
- jedes Mal, wenn man etwas kauft, ein Token in andere Condition zu schreiben: "Löschwzwer gekauft", dort sammelt man Tokens. Gdw. man 20 Tokens, die man jedes mal einfüllt hat in dieser Condition, dann dann nimmt man Kante, die mit 20 gewichtet ist

![_2022-02-24-17-14-21](_resources/_2022-02-24-17-14-21.png)

![_2022-02-24-17-19-44](_resources/_2022-02-24-17-19-44.png)

> Klausuraufgabe zu Petri Netze und Statecharts, beliebt ist bei Petri Netzen Invarianten zu berechnen, aber in der Klausur nicht so groß das Petri Netz
