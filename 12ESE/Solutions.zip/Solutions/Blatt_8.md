![_2022-02-25-20-01-06](_resources/_2022-02-25-20-01-06.png)

# 1
## a)
### First question
![_2022-02-26-02-35-15](_resources/_2022-02-26-02-35-15.png)

- "[...] last assignment" when a wait occurs in the process, then it's executed
- also variables are not synthesizable, because signals are like wires in hardware

### Second question
![_2022-02-26-03-44-45](_resources/_2022-02-26-03-44-45.png)
- because we can't synthesize them, no direkt representation in actual hardware. It's just for simulation issues

### Third question
![_2022-02-26-05-14-21](_resources/_2022-02-26-05-14-21.png)
- but this can also happen within one process. But it's kind of strange if you write this in your code, so it normally just happens if you have 2 processes and you didn't recognize it:
  ![_2022-02-26-05-21-25](_resources/_2022-02-26-05-21-25.png)

![_2022-02-26-05-14-07](_resources/_2022-02-26-05-14-07.png)
- we write to things simultaniously
- if one does have just bits, then simulation will stop with an error
- to solve right-right conflicts we have resolution functions

## b
- gute Strategie, wenn man den Output nochmal als Signal definiert und das Signal außerhalb der Prozesse auf den zuweist
> very likely a implementation task for vhdl in the exam, maybe just a 3 bit counter with design and testbench

![_2022-02-26-05-22-14](_resources/_2022-02-26-05-22-14.png)

![_2022-02-26-05-24-48](_resources/_2022-02-26-05-24-48.png)
- natural is a datatype that means we have just positive integers with the 0
  - from 0 to the highest representation of the integer, propably 32Bit, so 2^32
- the third part is the default value

![_2022-02-26-05-37-21](_resources/_2022-02-26-05-37-21.png)
- we have clock at 50MHz, but we want the counter in 1Hz, so we definte a constant -> MaxCount: this is the value, how often we have to count our clock until we increase our counter
  - in example have 50MHz clock, so we have count 50 Mio times until we can count our counter up, because then 1s is over
- clock divider: is just this counter "on lower level", we will increase our clock divider everytime the clock has a rising edge and then if the maxCount is arrived, we reset our clock divider and then set our counter to +1

![_2022-02-26-05-54-43](_resources/_2022-02-26-05-54-43.png)
- if StartPause pressed, we just change our state
- `rst` is active-low, normally the reset is high, so 1 and just if it's 0, we reset
- increase clockDivider when we have a rising edge in the clock
  - just don't do this if the clock divider is at the highest number of the integers or we have rst signal
- `clk'event`: When you have worked with VHDL code written by many other FPGA engineers, you are bound to notice that there are two common ways to model an edge detector in VHDL. There’s the rising_edge(clk) statement, and there’s the old style clk'event and clk = '1' method.<br>
The two if-statements do the same thing once the code is on the FPGA. They postulate that whatever is inside of the if-statement happens on the rising edge of the trigger signal, usually, the clock signal.
https://vhdlwhiz.com/clkevent-vs-rising_edge/
- In IEEE-1076.6-1999 "IEEE-Standard für die RTL-Synthese (VHDL Register Transfer Level)" werden die Ausdrücke explizit angegeben, die "eine positive Taktflanke darstellen sollen, wenn sie als Bedingung in einer if- Anweisung verwendet werden" definiert als:<br>
  ```
  RISING_EDGE (clk_signal_name)
  clk_signal_name'EVENT und clk_signal_name = '1'
  clk_signal_name = '1' und clk_signal_name'EVENT
  ```
  https://qastack.com.de/electronics/174801/what-is-the-use-of-event-in-vhdl

### Testbench
![_2022-02-26-08-43-26](_resources/_2022-02-26-08-43-26.png)
- in Testbench the signals are the inputs and outputs of our design
- generic map: set generic values to other values
- port map: set signals to ports from design
- ps = picoseconds

![_2022-02-26-09-30-32](_resources/_2022-02-26-09-30-32.png)

![_2022-02-26-09-33-04](_resources/_2022-02-26-09-33-04.png)
- std_logic_vector: is 6 bit vector "here", every bit in this 6 bit vector would then go onto a specific bin of the fpga and at this specific pin we would then build a LED on it. So in our VHDL Design, we don't look at it right now, but we have our output counter bits and at this specific bits we then would, we would then port them on a specific pin of the fpga, such that the led would lighten up

# 2
![_2022-02-26-09-49-32](_resources/_2022-02-26-09-49-32.png)

![_2022-02-26-09-53-40](_resources/_2022-02-26-09-53-40.png)
- microcontroller very cheap but slow
- assic very expenisive, but very fast
- cpu and fpga are somewhere in the middle
- look for pareto front and we see: the cpu is dominated by the fpga, the cpu is more expensive and also slower then the fpga, so it's dominated, it's not in our pareto front, but the other devices are
