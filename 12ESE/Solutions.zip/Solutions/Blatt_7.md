![_2022-02-25-12-22-09](_resources/_2022-02-25-12-22-09.png)
> VHDL sehr klaururreleavnt, irgendwas implementieren, eine Testbench oder derartiges

# 1
## a)
![_2022-02-25-12-23-38](_resources/_2022-02-25-12-23-38.png)

![_2022-02-25-12-30-54](_resources/_2022-02-25-12-30-54.png)

![_2022-02-25-12-31-20](_resources/_2022-02-25-12-31-20.png)

## b)
![_2022-02-25-12-40-36](_resources/_2022-02-25-12-40-36.png)
- sel ist das xy

![_2022-02-25-12-44-31](_resources/_2022-02-25-12-44-31.png)
- wait on ohne Sensitivitätsliste, sonst oben auskommentieren und wait on kommentieren
  - warten bis sich irgendetwas ändert. Sobald sich select bit ändert, beginnen wir Prozess von oben nochmal

# 2
![_2022-02-25-12-46-38](_resources/_2022-02-25-12-46-38.png)

![_2022-02-25-12-51-10](_resources/_2022-02-25-12-51-10.png)

> gute Klausuraufgabe, kam schonmal dran, dass man einen Counter implementieren sollte in VHDL, etwas sensitiv auf clock

## a) + b)
![_2022-02-25-12-56-47](_resources/_2022-02-25-12-56-47.png)
- rising edge: wenn unsere clock hochgeht von 0 auf 1
- unsigned, weil wir wirklich nur Binärzahlen wollen ohne Vorzeichen kümmern
- am Ende geänderte Signale auf Output setzen

### Testbench
![_2022-02-25-13-01-13](_resources/_2022-02-25-13-01-13.png)
- clock ansteuern alle 5 Nanusekunden, machen das bis 20 clock cycle um sind

![_2022-02-25-13-03-41](_resources/_2022-02-25-13-03-41.png)

## c)
![_2022-02-25-17-09-41](_resources/_2022-02-25-17-09-41.png)
- zählen 5 mal rauf, bis overflow, bedeutet mit 100MHz / 5 bekommen wir eine Änderung
- aber das ist nur Frequenz von Änderung. Bis wir eine Periode haben brauchen wir Bereich unten rechts, einmal hoch und runter. Bedeutet das müssen wir nochmal durch 2 teilen, sodass wir wirklich Frequenz vom Outputsignal haben
-> unser cout ist 10 mal so langsam, wie unsere clock
- Hardwaretyp: 10 zu 1 clock divider
- overflow unpassendes Wort, da sollte besser reset stehen
- 20Mhz wäre immer, wenn wir die Hälfte der Periode nehmen **($\frac{100}{2 * 10^6}s=\frac{1}{2}\cdot 10^{-4}=\frac{1}{2}\cdot 10^{-4}=0.5\cdot 10^{-4} = 50*10^{-4}$ vergehen bis cout einmal hochgezählt wird)**, "einmal hochzählen ist 100MHz **($\frac{100}{10^6}s=10^{-4}s=100 \cdot 10^{-6}s$ vergehen bis count einmal hochgezählt wird)**"
    - **antiproportional:**
      - $100 \cdot 10^{-6}s$ für einmal hochzählen $\hat=$ $100MHz$
      <br>$\Downarrow \cdot 10\qquad\qquad\qquad\qquad\qquad\qquad\Downarrow : 10$
      - $5 \cdot 2 \cdot 100 \cdot 10^{-6}s$ für eine Periode $\hat=$ $10MHz$
        - es dauert $10$ Mal länger eine Periode von cout abzuschließen (count zweimal komplett bis 5 hochzuzählen, 5 Perioden der clk, 5 `rising_edge`'s) als eine Periode von clk. Daher sinkt die Frequenz

![_2022-02-25-17-10-55](_resources/_2022-02-25-17-10-55.png)

# 3
## a)
![_2022-02-25-17-14-12](_resources/_2022-02-25-17-14-12.png)

![_2022-02-25-17-41-50](_resources/_2022-02-25-17-41-50.png)
- es kann niemals sein, dass $c_1 = c_0 = 1$
- wir teilen Schaltkreis immer auf, wenn wir 8 Bits haben, teilen wir zuerst in 4 Bits auf usw. Man bekommt dadurch ein c1h und ein c0h und auf der andenre Seite entsprechendes
- eigentlich ist für diesen Vergleich nur die erste Zahl wichtig, denn die sagt schon $a$ ist auf jeden Fall größer als $b$
- c1h und c0h sind genau diese c1 und c0 aus Tabelle. Wenn c1h 1 ist, dann wissen wir a > b und vice versa. Wenn beide 0 sind, dann wissen wir garnichts, denn dann sind beide gleich, dann müssen wir uns erst den hinteren Teil (also low) angucken. Und beim hinteren Teil bekommen wir auch raus, in diesem Fall wäre b größer als a

![_2022-02-25-18-07-04](_resources/_2022-02-25-18-07-04.png)
- Tabelle mit allen 2^4 Möglichkeiten, welche Kombinationen von c1h, c0h, c1l, c0l vorkommen können und dann überlegt man sich, was für einen Output das bei c1 und c0 generieren würde
- streiche -> c1x und c0x können nie 1 1 sein
- Auswertung:
  - wenn c1h 1 ist, dann ist auf jeden Fall auch c1 eine 1
  - wenn c0h 1 ist, dann ist auf jeden Fall auch c0 eine 1
  - wenn c1h und c0h beide 0 sind, dann kommt es drauf an, was der low Teil einem gibt
- Binärbaum aus KI

### Karnaugh Diagram
- man schaut, wo die 1er sind, wie kann man die zu Rechtecken, Quadraten zusammenführen. Und dann schaut man, was sich da wegkürzen lässt
- gibt genug andere Methoden noch, wie Klein McCluskey

![_2022-02-25-18-20-16](_resources/_2022-02-25-18-20-16.png)
- man schaut graphisch, ob man zusammenhängende Quadrate, Rechtecke, Linien usw. hin, weil dann kann man was rauskürzen
- wenn man lilanes Recheckt anschaut, dann sind da nur 1er oder don't cares, die nicht interesseren, die kann man also einfach mitnehmen
- coh bleibt gleich -> man kann c1h was einmal negiert und nicht negiert vorkommt rausstreichen
- vom lila Recheckt bleibt nur coh übrig, denn unser Rechteck geht über alle Spalten, also ist unser low Teil völlig irrelevant, da sich das alles wegkürzt
- irgendwann alle 1er abgedeckt in Diagramm -> das ist schon die Formel

![_2022-02-25-18-30-49](_resources/_2022-02-25-18-30-49.png)
- man geht auch über Ecken hinaus, weil man hier, wenn wir das hier umsortieren würden, dass diese Reihe unten ist, dann hätten wir auch hier wieder unser Quadrat

![_2022-02-25-18-31-20](_resources/_2022-02-25-18-31-20.png)

![_2022-02-25-18-33-13](_resources/_2022-02-25-18-33-13.png)

## b) c) d)
![_2022-02-25-18-34-17](_resources/_2022-02-25-18-34-17.png)

![_2022-02-25-18-35-52](_resources/_2022-02-25-18-35-52.png)
- std_logic_vector von 0 bis 0 ist nur ein Bit
- als Component haben wir beim 2-Bit Compoerator, den 1-Bit Comperator

![_2022-02-25-18-35-03](_resources/_2022-02-25-18-35-03.png)

![_2022-02-25-19-53-04](_resources/_2022-02-25-19-53-04.png)

![_2022-02-25-19-59-10](_resources/_2022-02-25-19-59-10.png)
