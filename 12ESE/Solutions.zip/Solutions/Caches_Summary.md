# Caches summary
![_2022-03-01-15-08-39](_resources/_2022-03-01-15-08-39.png)
- The placement policy decides where in the cache a copy of a particular entry of main memory will go. If the placement policy is free to choose any entry in the cache to hold the copy, the cache is called fully associative. At the other extreme, if each entry in the main memory can go in just one place in the cache, the cache is direct-mapped. Many caches implement a compromise in which each entry in the main memory can go to any one of N places in the cache, and are described as N-way set associative.
- Choosing the right value of associativity involves a trade-off. If there are ten places to which the placement policy could have mapped a memory location, then to check if that location is in the cache, ten cache entries must be searched. Checking more places takes more power and chip area, and potentially more time. On the other hand, caches with more associativity suffer fewer misses (see conflict misses, below), so that the CPU wastes less time reading from the slow main memory.
- **Direct Mapped Cache**: It does not have a placement policy as such, since there is no choice of which cache entry's contents to evict, can also be called a "one-way set associative" cache
  - This means that if two locations map to the same entry, they may continually knock each other out
  - Although simpler, a direct-mapped cache needs to be much larger than an associative one to give comparable performance, and it is more unpredictable
  - Let x be block number in cache, y be block number of memory, and n be number of blocks in cache, then mapping is done with the help of the equation x = y mod n.
- **Two-way set associative cache:**
  - If each location in the main memory can be cached in either of two locations in the cache, one logical question is: which one of the two? which one of the two? The simplest and most commonly used scheme, shown in the right-hand diagram above, is to use the **least significant** bits of the memory location's index as the index for the cache memory, and to have two entries for each index. One benefit of this scheme is that the tags stored in the cache do not have to include that part of the main memory address which is implied by the cache memory's index.
  - "One benefit of this scheme is that the tags stored in the cache do not have to include that part of the main memory address which is implied by the cache memory's index. Since the cache tags have fewer bits, they require fewer transistors, take less space on the processor circuit board or on the microprocessor chip, and can be read and compared faster"
  - Also LRU is especially simple since only one bit needs to be stored for each pair.
- A **cache miss** is a failed attempt to read or write a piece of data in the cache

# Cache row, Cache line, Cache set
**Cache row** entries usually have the following structure:

  ![_2022-03-01-16-11-55](_resources/_2022-03-01-16-11-55.png)
  - The **data block** (cache line) contains the actual data fetched from the main memory. The **tag** contains (part of) the address of the actual data fetched from the main memory. The **flag bits**: An **instruction cache** requires only one flag bit per cache row entry: a valid bit. The **valid bit** indicates whether or not a cache block has been loaded with valid data. On power-up, the hardware sets all the valid bits in all the caches to "invalid". A **data cache** typically requires two flag bits per cache line – a **valid bit** and a dirty bit. Having a **dirty bit** set indicates that the associated cache line has been changed since it was read from main memory ("dirty"), meaning that the processor has written data to that line and the new value has not propagated all the way to main memory.
    - The **"size"** of the cache is the amount of main memory data it can hold. This size can be calculated as the number of bytes stored in each data block times the number of blocks stored in the cache. (The tag, flag and error correction code bits are not included in the size,[13] although they do affect the physical area of a cache.)

An **effective memory address** which goes along with the **cache line** (<u>memory block</u>) is split (MSB to LSB) into the tag, the index and the block offset.

  ![_2022-03-01-16-20-27](_resources/_2022-03-01-16-20-27.png)
  - The **index** describes which cache set that the data has been put in. The index length is $\displaystyle \lceil \log _{2}(s)\rceil$ bits for s cache sets.
  - The **block offset** specifies the desired data within the stored data block within the cache row. Typically the effective address is in bytes, so the block offset length is $\displaystyle \lceil \log _{2}(b)\rceil$ bits, where b is the number of bytes per data block
  - The **tag** contains the most significant bits of the address, which are checked against all rows in the current set (the set has been retrieved by index) to see if this set contains the requested address. If it does, a cache hit occurs. The tag length in bits is as follows:

```
tag_length = address_length - index_length - block_offset_length
```

Image below shows the hardware for a C = 8-word, N = 2-way set associative cache. The cache now has only S = 4 **sets** rather than 8. Thus, only log24 = 2 set bits rather than 3 are used to select the set. The tag increases from 27 to 28 bits. Each set contains two ways or degrees of associativity. Each way consists of a data block and the valid and tag bits. The cache reads blocks from both ways in the selected set and checks the tags and valid bits for a hit. If a hit occurs in one of the ways, a multiplexer selects data from that way.
![_2022-03-01-17-19-36](_resources/_2022-03-01-17-19-36.png)

# Parameter
- **Cache size:** **🠒** Anzahl Cache Rows in Cache Sets (/Anzahl Sets /Anzahl Wörter)
  - Direct Mapped Cache ist **1-set-associative**
- **Memory size:** **🠒** Anzahl Memory Blöcke (geteilt durch Anzahl Wörter)
- **Offset Bits:** **🠒** Anzahl Wörter pro Memory Block (Bits, also mal 2)
- **Memory Block in Cache übertragen:**
  - eine bestimmte **Cacheline** übertragen: gewünschte Blocknummer * Anzahl Wörter
  - **Tag** ist um zu bestimmen, ob Adresse schon eingefügt wurde
    - Tag ist nicht so lang wie ganze Adresse, da:
      - die Offset Bits keine Rolle spielen, da man eine gesamte Cacheline kopiert
      - da die Index Bits schonmal eindeutig ein Set zuweisen und eine doppelte Adresse auch immer aufgrund ihres Index dem gleichen Set zugewiesen wird wo sie dann aufgrund des gleichens Offests einen Cache Hit verursacht
  - **Index** bestimmt welches Set bzw. welcher Cache Row (Directly Mapped Cache)
    - die 2 mittleren Bits der letzten Hexzahl der übergebenen Zahl entscheiden in welchem Set bzw. welcher Cache Row (Directly Mapped Cache) die Cache Line landet
    - die 2 letzten Bits der letzten Hexzahl der gewählten Adresse (übergebene Zahl / Anzahl Wörter) entscheiden in welchem Set bzw. welcher Cache Row (Directly Mapped Cache) die Cache Line landet

# Direct Mapped Cache
![_2022-03-02-04-28-11](_resources/_2022-03-02-04-28-11.png)
```
Bits(hex='1FF').bin ❯ '000111111111'
Bits(hex='3Fe').bin ❯ '001111111110'
```

![_2022-03-02-04-29-08](_resources/_2022-03-02-04-29-08.png)

![_2022-03-02-04-29-37](_resources/_2022-03-02-04-29-37.png)

![_2022-03-02-04-30-05](_resources/_2022-03-02-04-30-05.png)

![_2022-03-02-04-30-37](_resources/_2022-03-02-04-30-37.png)

![_2022-03-02-04-31-24](_resources/_2022-03-02-04-31-24.png)

![_2022-03-02-04-31-44](_resources/_2022-03-02-04-31-44.png)

![_2022-03-02-04-32-10](_resources/_2022-03-02-04-32-10.png)

![_2022-03-02-04-32-30](_resources/_2022-03-02-04-32-30.png)

![_2022-03-02-04-34-04](_resources/_2022-03-02-04-34-04.png)

![_2022-03-02-04-34-17](_resources/_2022-03-02-04-34-17.png)

![_2022-03-02-04-34-35](_resources/_2022-03-02-04-34-35.png)

![_2022-03-02-04-34-47](_resources/_2022-03-02-04-34-47.png)

![_2022-03-02-04-35-24](_resources/_2022-03-02-04-35-24.png)

![_2022-03-02-04-35-43](_resources/_2022-03-02-04-35-43.png)

![_2022-03-02-04-36-15](_resources/_2022-03-02-04-36-15.png)

![_2022-03-02-04-36-30](_resources/_2022-03-02-04-36-30.png)

```
hex(0x1FF * 4) ❯ '0x7fc'
hex(0x1C2 * 4) ❯ '0x708'
hex(0x1A8 * 4) ❯ '0x6a0'
hex(0x161 * 4) ❯ '0x584'
hex(0xF3 * 4) ❯ '0x3cc'
hex(0x9F * 4) ❯ '0x27c'
hex(0x36 * 4) ❯ '0xd8'
hex(0x9F * 4) ❯ '0x27c'
hex(0x1A8 * 4) ❯ '0x6a0'
```
```
hex(0x1FF * 2) ❯ '0x3fe'
hex(0x1C2 * 2) ❯ '0x384'
hex(0x1A8 * 2) ❯ '0x350'
hex(0x161 * 2) ❯ '0x2c2'
hex(0xF3 * 2) ❯ '0x1e6'
hex(0x9F * 2) ❯ '0x13e'
hex(0x36 * 2) ❯ '0x6c'
hex(0x9F * 2) ❯ '0x13e'
hex(0x1A8 * 2) ❯ '0x350'
hex(0x161 * 2) ❯ '0x2c2'
```
- 1FF,1C2,1A8,161,F3,9F,36,9F,1A8
- 3fe,384,350,2c2,1e6,13e,6c,13e,350,2c2
- 7fc,708,6a0,584,3cc,27c,d8,27c,6a0

# 2-Set-Associative-Cache
- die Sets sind in der Cache Table die einzelnen Zeilen

![_2022-03-02-05-14-57](_resources/_2022-03-02-05-14-57.png)

![_2022-03-02-05-15-32](_resources/_2022-03-02-05-15-32.png)

![_2022-03-02-05-16-08](_resources/_2022-03-02-05-16-08.png)

![_2022-03-02-05-16-31](_resources/_2022-03-02-05-16-31.png)

![_2022-03-02-05-17-05](_resources/_2022-03-02-05-17-05.png)

![_2022-03-02-05-18-23](_resources/_2022-03-02-05-18-23.png)

![_2022-03-02-05-18-44](_resources/_2022-03-02-05-18-44.png)

![_2022-03-02-05-20-07](_resources/_2022-03-02-05-20-07.png)

![_2022-03-02-05-21-22](_resources/_2022-03-02-05-21-22.png)

![_2022-03-02-05-21-55](_resources/_2022-03-02-05-21-55.png)

![_2022-03-02-05-22-13](_resources/_2022-03-02-05-22-13.png)

![_2022-03-02-05-22-36](_resources/_2022-03-02-05-22-36.png)

![_2022-03-02-05-22-54](_resources/_2022-03-02-05-22-54.png)

![_2022-03-02-05-23-46](_resources/_2022-03-02-05-23-46.png)

![_2022-03-02-05-24-36](_resources/_2022-03-02-05-24-36.png)

![_2022-03-02-05-25-00](_resources/_2022-03-02-05-25-00.png)

![_2022-03-02-05-25-16](_resources/_2022-03-02-05-25-16.png)
