![_2022-02-26-10-03-39](_resources/_2022-02-26-10-03-39.png)

# 1
![_2022-02-26-10-04-16](_resources/_2022-02-26-10-04-16.png)
- Integrated circuit
- Test Development additional cost per die increased, because of the time of the testing machine being one of the most expensive resources. Pins that one has to expose, thats some engineering cost one does have to make during the design of the IC, that may also increase the cost, e.g. larger die to expose the pins to the tester. Tests cost a lot of money, "tester time very expensive"
- net profit, that not what one gets for selling, but for the company, substracted what manufactoring of the dies actually cost

![_2022-02-28-03-53-06](_resources/_2022-02-28-03-53-06.png)
- Y=yield
- W=test coverage
- die = chips cut form silicon wafers are also called die, that the chip without the molding, chip usually in proper package, most common used is the dual-inline package
- faulty ones = ic's - this one
- faulty recognized = the ones that one sorts out, the ones marked on the wafer as faulty. And then one just removes them. Is faulty IC's * W (test_coverage )
- faulty delivered are the faulty - faulty recognized ones
  - prefer to have as less as faulty chips actually delivered, because of fine
- delivered are the fault free + faulty delivered

![_2022-02-28-03-22-10](_resources/_2022-02-28-03-22-10.png)
- fab cost td has + additional cost for the testing, same for pe&td
- productions costs are the number of IC's * cost_per_ic + fab_cost
- fine: fauly_delivered * penalty
- revenue: "older_"fault_free_delived_ones * what_one_gets_per_IC
  - 70_000 * 20€
- net_profit: if add this up
  - revenue might be very hight for all these, but if just remove this fine from this revenue, one can see that only the PE&TD is the most proftitable design for company
  - "propably  revenue - production_cost - fine"


# 2
> a) possible exercise that might also go into the exam

![_2022-02-28-03-22-40](_resources/_2022-02-28-03-22-40.png)
- power consumption of a wireless sensor node

![_2022-02-28-14-11-42](_resources/_2022-02-28-14-11-42.png)
- Watt = Voltage * currence
   - 4W / 5V = 0.8A
- kWh gibt auch noch

## a)
![_2022-02-28-14-13-10](_resources/_2022-02-28-14-13-10.png)
- calculate area under curve

![_2022-02-28-14-18-24](_resources/_2022-02-28-14-18-24.png)

![_2022-02-28-14-18-34](_resources/_2022-02-28-14-18-34.png)

## b)
![_2022-02-28-14-21-06](_resources/_2022-02-28-14-21-06.png)
- use average calculated before, then calculate amount of seconds a day has and multiply by this number here
- if more familiar with kWh devide by 3600, one hour in seconds
  - 77760 / 3600 = 21.6
- e.g. USB Power Bank: 2000mAh, 5V because of USB, 5V * 2.2Ah = 11Wh -> see it would not be possible to use this powerbank to power this sensor node for even one day

## c)
![_2022-02-28-14-33-56](_resources/_2022-02-28-14-33-56.png)
- 12h per day -> last half of 21.6Wh using the battery
- 10.8Wh which we need to put in our battery. Capacity of battery should be 10.8Wh to have it run through the night

![_2022-03-01-01-06-42](_resources/_2022-03-01-01-06-42.png)
- charge 10.8Wh in 12 hours of sunlight, but also provide the current for the node during the day
- sensor node had maximum power load of 4W, that was the maximum in the graph
- 12h and 10.8Wh which lead again to 0.9W (10.8 / 12)
- 4.9W is what solar cell needs to provide in the time there is sunlight
- assuming that we're loading this constantly, we need to have 4W in Backup at each time
- $\frac{W}{\frac{W}{m^2}}=\frac{W \cdot m^2}{W}=m^2$
  - dagegen: $\frac{\frac{W}{m^2}}{W}=\frac{W}{W \cdot m^2}=\frac{1}{m^2}$
- need to have 4 watt in backup each time
- we can optimize this a little bit more and say whenever this sensor node is drawing it's 4W we don't charge the battery. So this would mean we don't have to provide 4.9W, but just 4W and we can do the calculation again and make this a little bit less, propably this will then be around 300
- can also argue that we only have to make sure that our battery is actually charged with the full 21.6Wh inside this 12 hour cycle. Divide by 12 hours leads to 1.8W on averag "to use the sensor for both day and night"
  - 138 is enough because one can typically also charge and discharge the battery at the same time

## d)
![_2022-02-28-14-34-44](_resources/_2022-02-28-14-34-44.png)

![_2022-03-01-01-11-52](_resources/_2022-03-01-01-11-52.png)
- car battery is powered $12$ at Volts. So this would mean something around $8$ Ah. Typically car battery has around $50$ to $100$Ah

# 3
![_2022-02-28-03-25-50](_resources/_2022-02-28-03-25-50.png)
- in real world it's $\mu W$ or $nW$

## a)
![_2022-03-01-03-05-27](_resources/_2022-03-01-03-05-27.png)
- have to adjust the $t$ variable
- the $t$ is minus this number that is took us here
  - auf diese Weise entspricht $t$ immer der Zeitspanne, die dieser Modus bereits aktiv ist
  - die Summanden ist Konstnate Werte, die das Switches braucht

![_2022-03-01-03-07-39](_resources/_2022-03-01-03-07-39.png)
![_2022-03-01-03-14-43](_resources/_2022-03-01-03-14-43.png)
- $10 \cdot 10^{-9} \cdot 250 \cdot 10^{-6} + 10 \cdot 10^{-9} \cdot 250 \cdot 10^{-6} = 20 \cdot 10^{-9} \cdot 250 \cdot 10^{-6} = 5000 \cdot 10^{-15} = 5\cdot 10^{-12}$
- $(t-2 \cdot 100 \cdot 10^{-9}) \cdot 10 \cdot 10^{-6} = t \cdot 10 \cdot 10^{-3} - 2 \cdot 100 \cdot 10^{-9} \cdot 10 \cdot 10^{-3} = t \cdot 10 \cdot 10^{-3} - 2 \cdot 10^{-0}$

![_2022-03-01-03-38-33](_resources/_2022-03-01-03-38-33.png)

## b)
![_2022-03-01-03-39-35](_resources/_2022-03-01-03-39-35.png)

### minimal mode sequence
![_2022-03-01-04-02-52](_resources/_2022-03-01-04-02-52.png)
- executed exactly at arrival time
- first only 100$\mu s$ and we calculated that we should be at least 236$\mu s$ to be more efficient to go into sleep

![_2022-03-01-04-03-05](_resources/_2022-03-01-04-03-05.png)
- calculate energy comsumption over this whole time period here

### calculate energy comsumption
![_2022-03-01-04-04-23](_resources/_2022-03-01-04-04-23.png)

![_2022-03-01-04-15-28](_resources/_2022-03-01-04-15-28.png)
- 4 summands:
  - three times run state, all tasks require 200 $\mu s$
  - transition going from run to idle and from idle to run again, then we have just $80\mu s$ left, where we are in idle
  - transition from / to sleep 2 times and then 100$\mu s$ in sleep mode
  - last sleep mode, one transition, remaining $200\mu s$ totally in sleep
- $3 \cdot 200 \cdot 10^{-9} \cdot 500 \cdot 10^{-3} = 3 \cdot 100000 \cdot 10^{-12} = 3 \cdot 10^{-9} = 300 \cdot 10^{-9}$
- usexase for transition from idle to sleep: that probably you're waiting for something, it never happened and after specifif amount of time one goes into the sleep state

-------------------------------------------------------------------------------

![_2022-03-01-04-27-39](_resources/_2022-03-01-04-27-39.png)
