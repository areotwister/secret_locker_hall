- which means this thing is actually deadlockfree because nothing can go wrong, the Tokens will remain constant in all this rows here and all this paths here and there will always be a Token for the Printer P1 and Printer P2 and there will be a Token für the Processes, so we can’t have a deadlock actually
- Unterschied zwischen cache set und cache line und cache row

# ToDo:
- Mealy und Moore vorwärts und rückwärts
- Überblick verschaffen bei Umwandlung und Or- und And-Nodes mit und ohne History Node
- Überblick über Invariants Matrix und so
- was ist:  FIFO - first in, first out
- stimmt Aussage unten auf dieser Folie:?
![_2022-03-03-02-20-33](_resources/_2022-03-03-02-20-33.png)
- Was ist wenn man ein TimeoutEvent hat und wärhendesen ein anders Event reinkommt?
