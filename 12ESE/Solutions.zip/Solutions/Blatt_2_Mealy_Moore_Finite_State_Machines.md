![_2022-02-23-04-25-45](_resources/_2022-02-23-04-25-45.png)

# 1
## a)
![_2022-02-23-04-27-28](_resources/_2022-02-23-04-27-28.png)
- keine Time, weil man ganz viele Zustände machen müsste
- keine Nebenläufigkeit, weil man für jeden Fall, der zusammenkommen kann einen eigenen State machen -> zu viele States
- keine komplexen Datentypen -> nicht float und int vermischen und Berechnungen machen
-> daher gibt es Statecharts

![_2022-02-23-04-32-34](_resources/_2022-02-23-04-32-34.png)

## b)
![_2022-02-23-04-50-03](_resources/_2022-02-23-04-50-03.png)
- Acceptor bekommt Eingabe von einem Wort und soll sagen, ob Eingabe gültig oder nicht gültig
- Startzustand hat Pfeil
- unten Errorstate, den man eigentlich nicht braucht, weil Automaten schon so definiert sind, dass wenn in S0 ein a auftaucht, dieses Wort dann nicht gültig ist
  - man hat auch Problem, wenn man am Ende nochmal ein a bekommt

## c)
![_2022-02-23-04-58-17](_resources/_2022-02-23-04-58-17.png)
- wichtig, dass **finite** statemachine

![_2022-02-23-06-44-40](_resources/_2022-02-23-06-44-40.png)
- wenn wir n unendlich machen, würden auch unendlich viele States hinzukommen und da es eine **finite** Statemachine ist, können wir das nicht darstellen
- der zweite Autoamt würde auch abababbbbababa akzeptieren

# 2
## a)
![_2022-02-23-06-55-54](_resources/_2022-02-23-06-55-54.png)
- Mealy hat Ausgabe auf Kante
- Moore hat Ausgabe in State drin
- wir haben hier einen Mealy Automaten

## b)
![_2022-02-23-07-07-58](_resources/_2022-02-23-07-07-58.png)
- zuerst beim Startzustand anfangen
- was man beim Moore Automaten beachten muss, ist dass wenn man den ersten Zutand hat, im Zustand ist der Output gespeichert, also muss man sagen, entweder man beachtet den ersten Output nicht, oder man tut nen State dazu einfügen, wir machen letzteres
- **von jedem State aus, unabhänig vom Ouput, alle möglichen Inputs durchgehen und schauen, ob man zu einem State mit Output kommt, der bereits eingezeichnet ist oder nicht**
- bei gleichem State und Output macht man Loop in sich selbst

## c)
![_2022-02-23-07-32-14](_resources/_2022-02-23-07-32-14.png)
- formeller Beweis -> Zustände kodieren zu logischen Formlen und zeigen, dass logische Formeln äquivalent sind

![_2022-02-23-07-33-56](_resources/_2022-02-23-07-33-56.png)

## d)
![_2022-02-23-07-35-18](_resources/_2022-02-23-07-35-18.png)
-> beide sind genau gleichmächtig
- gibt "glaub" kein Szenario, wo Moore kompakter als Mealy, Moore ist immer kompakter oder gleich

# Echtzeitsysteme
![_2022-02-23-07-47-21](_resources/_2022-02-23-07-47-21.png)
- wenn nicht zu einer Katastrophe kommt, dann hat man softe Zeigbedingungen. Dann endet es nicht in einer Katastrophe, man sagt das ist auch ok, aber nicht so cool
- darf nicht statistisch sein, es muss 100% garantiert sein und nicht in 90% passt es schon
- Wikipedia: Unterschied ungangsprachliches Echtzeit und technischem Echtzeit

![_2022-02-23-07-57-17](_resources/_2022-02-23-07-57-17.png)
- bei ES oftmals sehr schnell und in definiertem Intervall

![_2022-02-23-07-59-35](_resources/_2022-02-23-07-59-35.png)

![_2022-02-23-08-01-13](_resources/_2022-02-23-08-01-13.png)
