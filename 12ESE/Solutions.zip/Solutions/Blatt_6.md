![_2022-02-24-17-41-52](_resources/_2022-02-24-17-41-52.png)

# 1
## a)
![_2022-02-24-18-14-33](_resources/_2022-02-24-18-14-33.png)
- keine Zahl bedeutet, default Wert 1
- zwei Zustände, entweder wir drucken oder wir warten auf den nächsten Druckauftrag. Zwei Zustände in System, die wir haben
- wieder zurückkommen, da haben wir keine bestimmten Vorbedingungen, irgendwann sind wir fertig, daher nehmen wir eine Zeitanzahl
- Initialzustand, dass man im Idle-Zustand ist

## b)
![_2022-02-24-18-15-54](_resources/_2022-02-24-18-15-54.png)

![_2022-02-24-18-18-20](_resources/_2022-02-24-18-18-20.png)

### Anzahl Kanten bei n Transitionen worst case
![_2022-02-24-18-26-49](_resources/_2022-02-24-18-26-49.png)
- wenn jede Transition aktiv werden kann (es kann im allgemeinen nicht jede Transition aktiv werden)
- wenn jede Transition aktiv werden kann, dann kann man von jedem State in jeden anderen State kommen

![_2022-02-24-18-27-32](_resources/_2022-02-24-18-27-32.png)

> Statecharts und Petri-Netze haben so ihr Anwendungsgebiet und sind verschiedene Spezifikationen, wie man Embedded System modellieren kann

# 2
> sehr beliebt in Klausur

## a)
![_2022-02-24-18-28-58](_resources/_2022-02-24-18-28-58.png)
- nur ein Token in place und über Kante geht auch nur ein Token weg

![_2022-02-24-18-37-44](_resources/_2022-02-24-18-37-44.png)

![_2022-02-24-18-52-24](_resources/_2022-02-24-18-52-24.png)
- **Vorgehen:**
  - man schaut sich einen Place an, z.B. S1 und schaut wieviele Kanten hat man da überhaupt. Man schaut sich zuerst alle eingehenden Kanten an, von diesen bekommt man Tokens dazu, das ist Kante von T1 und T8, bei T1 und T8 schreibt man jetzt eine 1 rein. Dann schaut auf ausgehende Kanten, da haben wir Kanten nach T7 und T2, hier verlieren wir unsere Tokens, also -1. Bei allen anderen Transitions verliert und gewinnt man keine Tokens, daher 0

## b)
![_2022-02-24-18-54-54](_resources/_2022-02-24-18-54-54.png)
- Lösungvektor c ist eine Invariante

![_2022-02-24-18-55-41](_resources/_2022-02-24-18-55-41.png)

### Stufenform
![_2022-02-24-20-06-06](_resources/_2022-02-24-20-06-06.png)

![_2022-02-24-20-05-42](_resources/_2022-02-24-20-05-42.png)
- immer komplementäre Sachen, addieren Zeilen, bekommen 0 Zeilen, die man streichen kann

![_2022-02-24-23-04-11](_resources/_2022-02-24-23-04-11.png)
- wenn Z7 + Z1 rutscht einem eine 1 rein, aber mit Zeile Z5, die geändert, bekommt man wieder eine -1 rein, also hier noch Z7 + Z5' machen
- Stufenform bringt nicht groß weiter, da wir nur noch 4 Zeilen haben und keine 8 Zeilen mehr

### Methode für schnelle Invariante
![_2022-02-24-23-08-44](_resources/_2022-02-24-23-08-44.png)
- schauen, ob es Spalten gibt, wenn man die addiert, dass die zusammen 0 ergeben

![_2022-02-24-23-33-56](_resources/_2022-02-24-23-33-56.png)
- **man kann auch von einem viel früheren Zustand sehen, was die Invarianten sind, man muss es nicht umgedingt in Stufenform bringen. Wenn in Klausur verlangt, dann muss man es auch machen**

![_2022-02-24-23-11-26](_resources/_2022-02-24-23-11-26.png)
- rot unterstrichen ist 2te Lösung
- grün ist 4te Lösung die nicht aufgeführt
- Invariante: in diesem Subset verändert sich die Anzahl der Tokens nicht

## c)
![_2022-02-24-23-13-15](_resources/_2022-02-24-23-13-15.png)

![_2022-02-24-23-27-53](_resources/_2022-02-24-23-27-53.png)
- **grün:** es geht um Prozess 1, entweder er druckt nicht oder er benutzt den Drucker 1 oder er benutzt den Drucker 2 -> bedeutet ein P1 kann nicht gleichzeitig überhaupt nicht drucken und Drucker 1 benutzen. Entweder Prozess 1 druckt oder er druckt nicht
- **orange:** handelt ich um Prozess 2, gleich wie oben
- **rot:** handelt es sich um Drucker 1, entweder Drucker 1 ist frei, er druckt nicht oder er wird von Prozess 1 oder 2 benutzt
- **lila:** äquivalent zu Invariante 3

### Frage Tutorat
- wir hatten gesagt die Anzahl Tokens ist immer 1, also entweder wir haben in S1 ein Token, dass nicht druckt oder wir haben ein Token in S4, dass mit P1 druckt oder wir haben ein Tokan, dass in S8 ist, also der Prozess 1 mit Drucker 2 druckt
- Da war Frage, ob das Immer-Token = 1 sein muss bei den Invarianten -> das ist eben nicht der Fall, es kann sein in diesem Beispiel, wenn wir durchgehen, dann sehen wir, dass immer nur 1 Token in diesem Subset ist, aber bei anderen Petrinetzen kann das anders sein, z.B. das die Tokenanzahl in einem Subset immer 3 ist. Wir würden nie irgendwelche Tokens dazu oder wegbekommen in diesem Subset. Die Anzahl Tokens in diesem Subset bleibt immer gleich
- **Invariante:** Anzahl der Tokens bleibt invariant

### Völker
![_2022-02-25-01-21-32](_resources/_2022-02-25-01-21-32.png)
- inside this path, following the edges, all markings will remain constant
- if we have one marking inside here, where we start, then this marking will never get lost, it will always go back or stays here or here
- also the tokens will never get lost, which means that the printer is either free, it's printing from P1 or it's printing from P2
- same also second Printer
- which means this thing is actually deadlockfree because nothing can go wrong, the Tokens will remain constant in all this rows here and all this paths here and there will always be a Token for the Printer P1 and Printer P2 and there will be a Token für the Processes, so we can't have a deadlock actually

# 3
![_2022-02-24-23-46-55](_resources/_2022-02-24-23-46-55.png)

## a) + b)
![_2022-02-25-01-51-41](_resources/_2022-02-25-01-51-41.png)

![_2022-02-25-02-06-17](_resources/_2022-02-25-02-06-17.png)

![_2022-02-25-02-09-27](_resources/_2022-02-25-02-09-27.png)

![_2022-02-25-02-13-43](_resources/_2022-02-25-02-13-43.png)
- `std_logic_vector(1 downto 0)` bedeutet, dass wir 2 Bit haben. Wenn A 4-Bit sein sollten, wie beim 4-Bit-Carry-Ripple Addierer, dann `3 downto 0`
- `std_logic` ist 1-Bit
- 2 Bit bei `A` und `B`, die sich ändern können und `Cin` -> 2^5 Möglichkeiten
- A, B, Cin verändern wir, S und Cout schauen wir an

![_2022-02-25-12-09-14](_resources/_2022-02-25-12-09-14.png)

![_2022-02-25-12-10-08](_resources/_2022-02-25-12-10-08.png)
- alle 32 Möglichkeiten abgedeckt

![_2022-02-25-12-10-55](_resources/_2022-02-25-12-10-55.png)
