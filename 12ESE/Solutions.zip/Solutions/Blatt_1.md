![_2022-02-22-18-54-31](_resources/_2022-02-22-18-54-31.png)

![_2022-02-22-18-55-42](_resources/_2022-02-22-18-55-42.png)

# 1
## a)
![_2022-02-22-22-21-58](_resources/_2022-02-22-22-21-58.png)

## b)
![_2022-02-22-23-06-03](_resources/_2022-02-22-23-06-03.png)
- HMI = Human machine interface

![_2022-02-22-23-07-48](_resources/_2022-02-22-23-07-48.png)
- Microntroller in Mitte
- wenn Temperatur zu hoch Ladestrom verringern

![_2022-02-22-23-19-12](_resources/_2022-02-22-23-19-12.png)
- wenn analoger Digitaler Sensor, dann muss digital gemacht werden mit A/D Converter
- PWM Pulsweitenmodulation
- H-Bridge macht von Gleichpsannung in Wechselspannung -> wird häufig bei Motoren benutzt

![_2022-02-22-23-23-53](_resources/_2022-02-22-23-23-53.png)
- UART: Ein Pin für Senden von Sachen (transmit), RX für Empfangen von Sachen (receive)

## c)
### i
![_2022-02-22-23-24-38](_resources/_2022-02-22-23-24-38.png)
- sowohl korrekt als auch falsch, ungenau wo genau Grenze
- ES kann man immer als Automaten darstellen, statemachine, petri netz, Büchi-Automat
- untere Def: ES ist Untekategorie von CPS
- Airback ist CPS
- IOT sind ES, die miteinander kommunizieren

### ii
![_2022-02-22-23-34-57](_resources/_2022-02-22-23-34-57.png)

![_2022-02-22-23-38-23](_resources/_2022-02-22-23-38-23.png)
- Echtzeit ist immer das was man als Echtzeit definiert, meistens ist Echtzeit, ein paar Nano/Milisekunden
- **Echtzeit**, alle Prozesse müssen unter Grenze von 3ms sein, Toleranzbereich, muss garantiert sein
  - bei soft constraint, hat man vielleicht noch nen kleinen Toleranzbereich, kann soft contraints geben, kommt auf Anwendung an
  ![_2022-02-22-23-45-39](_resources/_2022-02-22-23-45-39.png)
- **Zeiteffizientez** ist so schnell wie möglich sein, aber ist nicht Echtzeit

### iii
![_2022-02-22-23-47-09](_resources/_2022-02-22-23-47-09.png)
- nicht alle

> in Klausur schon häufiger sagen, was ein eingebettetes System ist, Beispiel nennen für eingebettes System und keins (-> normaler PC, weil nicht eigene spezifische Aufgabe)
![_2022-02-22-23-49-43](_resources/_2022-02-22-23-49-43.png)
- effizient sein ist gut, wenn es das ist
- beide Definitionnen, auch altenrative Definition am Ende der Folien ist korrekt
- Klausur orientiert sich sehr an Übungsblättern

# 2
![_2022-02-22-23-54-00](_resources/_2022-02-22-23-54-00.png)

## a)
![_2022-02-23-00-06-10](_resources/_2022-02-23-00-06-10.png)
- dependable -> hängt an anderen Systemen, muss zuverlässig sein
- sollte aber für Piloten sichtbar sein sodass man ess abeschalten kann
- echtzeit: schnell reagieren, wenn überschlägt
- reactive: soll auf überschlagen reagieren

![_2022-02-23-00-09-11](_resources/_2022-02-23-00-09-11.png)

![_2022-02-23-00-11-13](_resources/_2022-02-23-00-11-13.png)

## b)
![_2022-02-23-00-12-41](_resources/_2022-02-23-00-12-41.png)
- kleines System verbraucht verglichen mit Flugzeug so wenig Energie, dass es nciht ganz so schlimm ist
- um in Wettbewergsvorteil zu kommen sind Kosten nicht ganz so relevant

## c)
![_2022-02-23-00-15-07](_resources/_2022-02-23-00-15-07.png)
- muss effizient sein in vielen belangen
- es ist ein System für eine spezfische Aufgabe in einem größerem System eingebettet, welches reactive ist und real-time constraints hat

## d)
![_2022-02-23-02-57-10](_resources/_2022-02-23-02-57-10.png)
- AND ist die Nase-runter Operation
