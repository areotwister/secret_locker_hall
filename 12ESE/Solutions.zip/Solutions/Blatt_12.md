![_2022-03-04-17-37-47](_resources/_2022-03-04-17-37-47.png)

# 1
## a)
![_2022-03-04-18-05-17](_resources/_2022-03-04-18-05-17.png)

![_2022-03-04-18-06-05](_resources/_2022-03-04-18-06-05.png)

![_2022-03-04-18-08-46](_resources/_2022-03-04-18-08-46.png)
- ist durch das Struct verboten

![_2022-03-04-18-06-40](_resources/_2022-03-04-18-06-40.png)

![_2022-03-04-18-38-00](_resources/_2022-03-04-18-38-00.png)
- `char name[]` mit `unsigned int` tauschen, dann würde es gehen, weil dann kann man unbegrenzt Speicher allozieren

## b)
![_2022-03-04-18-07-36](_resources/_2022-03-04-18-07-36.png)

![_2022-03-04-18-54-42](_resources/_2022-03-04-18-54-42.png)

![_2022-03-04-18-08-12](_resources/_2022-03-04-18-08-12.png)

## c)
![_2022-03-04-18-09-17](_resources/_2022-03-04-18-09-17.png)

![_2022-03-04-18-10-00](_resources/_2022-03-04-18-10-00.png)
- in `printf` geben: es würde nicht die String Representation ausprinten, sondern die Integers
- bei `switch` immer darauf achten ein `break` dahinzumachen`
  - sonst wird solange alles ausgeführt bis ein `break` kommt

![_2022-03-04-18-10-20](_resources/_2022-03-04-18-10-20.png)

## d)
![_2022-03-04-18-10-43](_resources/_2022-03-04-18-10-43.png)
- Heap bzw. Static Memory

![_2022-03-04-18-11-35](_resources/_2022-03-04-18-11-35.png)

## e)
![_2022-03-04-23-10-42](_resources/_2022-03-04-23-10-42.png)

![_2022-03-04-23-04-16](_resources/_2022-03-04-23-04-16.png)
- vergessen, dass da ein `>=` sein muss, Buffersize ist 10, aber wir fangen bei 0 an zu zählen

![_2022-03-04-23-08-03](_resources/_2022-03-04-23-08-03.png)

## f)
![_2022-03-04-18-17-13](_resources/_2022-03-04-18-17-13.png)
- nimmt an, dass Button sowas ist wie rechts: also einfach wir können den drücken, dann haben wir entweder hier, wenn er nicht gedrückt ist, dann sind wir bei `hight` (oben), wenn wir ihn drücken, dann sind wir bei `low` (unten)
- Schaltung: Warum ist es low, wenn der Button gedrückt ist. Wenn der Button gedrückt ist, dann ist zwischen den beiden Lolipops eine Verbindug und dann wird $V_{Pin}$ auf Ground Level gezogen. Und wenn der Button nicht gedrückt ist, dann wird $V_{Pin}$ auf $V_{CC}$ gezogen. Diesen Wiederstand brauchen, wir nur wenn der Button gedrückt ist, damit wir hier nicht einen Kurzschluss haben

![_2022-03-04-23-12-06](_resources/_2022-03-04-23-12-06.png)

![_2022-03-04-23-17-39](_resources/_2022-03-04-23-17-39.png)

![_2022-03-04-23-19-17](_resources/_2022-03-04-23-19-17.png)
- FSM=Finite State Machine

![_2022-03-04-23-31-05](_resources/_2022-03-04-23-31-05.png)
- "Problem, dass man die ganze Zeit dauerspammen kann und bleibnt man die ganze Zeit in dieser Loop, anstatt einen Double Press zu triggern"
- wir geben immer States zurück, überall außer bei Hold, Single, Double gibt man keinen State zurück

![_2022-03-05-00-30-59](_resources/_2022-03-05-00-30-59.png)
- wenn wir pressen, dann gehen wir in State 1 und Speichern uns auch die Zeit ("now")
- "die If-Bedingungen sind immer das was auf den Kanten für Conditions steht und das nach der Conditions kommt in den Rumpf und die Statevariable wird zum neuen State abgeändert und ggf. wird Zeit gestoppt für eine spätere Bedingung"
  - "self loops sind meist wenn keine der Bedingungen greift"

## Code
![_2022-03-04-22-23-15](_resources/_2022-03-04-22-23-15.png)

![_2022-03-04-22-24-15](_resources/_2022-03-04-22-24-15.png)
- `print_sensor_sample`: Sensordaten + Zeitstempel

![_2022-03-04-22-28-04](_resources/_2022-03-04-22-28-04.png)
- `add_sample_safe` überprüft, ob überhaupt genug Platz da ist

![_2022-03-04-22-36-57](_resources/_2022-03-04-22-36-57.png)

![_2022-03-04-22-38-36](_resources/_2022-03-04-22-38-36.png)

![_2022-03-04-22-39-21](_resources/_2022-03-04-22-39-21.png)
- `readSensorSample` nehmen random value

![_2022-03-04-22-52-38](_resources/_2022-03-04-22-52-38.png)

![_2022-03-04-22-52-54](_resources/_2022-03-04-22-52-54.png)

# bei manchen `switch` fehlt ein `break`
![_2022-03-04-23-08-33](_resources/_2022-03-04-23-08-33.png)

![_2022-03-04-23-09-24](_resources/_2022-03-04-23-09-24.png)

# Implementierung von Feldbush
![_2022-03-05-00-55-24](_resources/_2022-03-05-00-55-24.png)

![_2022-03-05-00-55-50](_resources/_2022-03-05-00-55-50.png)

![_2022-03-05-00-58-14](_resources/_2022-03-05-00-58-14.png)
- Was machen, da keinen Button **🠒** Verbinde Pin mit VDD oder Ground

![_2022-03-05-00-58-54](_resources/_2022-03-05-00-58-54.png)

![_2022-03-05-00-59-09](_resources/_2022-03-05-00-59-09.png)
- hold
