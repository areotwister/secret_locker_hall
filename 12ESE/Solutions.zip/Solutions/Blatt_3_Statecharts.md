![_2022-02-23-17-40-04](_resources/_2022-02-23-17-40-04.png)

# 1
## a)
![_2022-02-23-17-45-36](_resources/_2022-02-23-17-45-36.png)
- daran denken, dass wenn man in einem Unterstate ist, man auch in allen Überstates ist

## b)
![_2022-02-23-17-56-01](_resources/_2022-02-23-17-56-01.png)
- Mode ist Or-Superstate
- bei 'door open' geht man wieder in History-Connector rein und geht dahin, wo man zuvor war
- bei 'off, b' präferiert man die Kante, die im hierarchischen Baum höher ist, also nicht ganz so verschachtelt ist -> bedeutet wir nehmen hier die off-Kante, weil wir da weiter rauskommen in der Ebene, das b beachtet man nicht weiter
- nach on landet man wieder im History-Mechanismus

## c)
![_2022-02-23-18-14-24](_resources/_2022-02-23-18-14-24.png)
- HIstory-Mechansimus umgehen, sodass man nach ausschalten und wieder-einschalten im Default-State landet
- History-Connector war für 2 Sachen:
  - wenn man Mikrowelle irgendwas drin bei 1600W, man macht kurz Mikrowelle auf, kurz von Radiator-on rausgehen, Tür wieder zu, aber will, dass es nicht wieder bei 400W anfängt, sondern bei 1600 weitermacht
  - Essen komplett aufgewämrt man schaltet, Mikrowelle aus und starte sie später wieder
-> History-Meachanismus muss dabehalten werden für den ersten Fall

![_2022-02-23-18-17-08](_resources/_2022-02-23-18-17-08.png)
- man tut nicht von 'Raditor on' direkt auf History zeigen, weil die Schrebweise für den Hstiory Connector so ist, dass man keine direkte Kante auf den History-Connector macht

## d)
![_2022-02-23-18-31-01](_resources/_2022-02-23-18-31-01.png)

![_2022-02-23-18-23-57](_resources/_2022-02-23-18-23-57.png)
- schauen, wo man solche Kante hat wie unten rechts
- bei 'Radiator on' muss man den History-Mechanismus beachten, d.h. man braucht für jeden State hier auch einen 'Radiator on' State. Es geht nicht, dass man da die ganzen Kanten runterzieht zu 'Radiator on' und dann hier wieder die Transiations hoch, weil wir nicht Wissen, welchen wir nehmen müssen -> D.h. man muss den 'Radiator on' State zweimal duplizieren, sodass man einen Radiator-on State für 400W,1000W,1600W hat
- weil der off-State höher Priorisiert wird, weil es ne Ebene höher geht, hat man da immer nicht-off. Wenn b kommt und off, dann muss man auf jeden Fall die off Kante nehmen

![_2022-02-24-02-32-49](_resources/_2022-02-24-02-32-49.png)
- Fehler, es muss "und nicht start" dazugeschrieben werden
- wenn von 400W ausgehen
  - wenn start und off und b gleichzeitig kommen, dann gehen wir in die off-Kante
  - wenn b und start gleichzeitig kommen, dann gehen wir über Radiator-on
  - wenn nur b kommen, dann können wir in 1000W wechseln

# 2
## a)
![_2022-02-24-02-40-23](_resources/_2022-02-24-02-40-23.png)

![_2022-02-24-02-43-31](_resources/_2022-02-24-02-43-31.png)
- manchmal in Klausur:
  - wenn man da noch einen State hätte, dann bekäme man 6
  - wenn man da noch einen weiteren State hätte, dann bekäme man 9
  - n*m

![_2022-02-24-02-47-04](_resources/_2022-02-24-02-47-04.png)

![_2022-02-24-04-08-53](_resources/_2022-02-24-04-08-53.png)
- Hiearchie nicht beachtet wenn 1am und friday soon gleichzeitig

![_2022-02-24-04-14-02](_resources/_2022-02-24-04-14-02.png)
- man kann in einem Schritt zu ES und tired gehen
- und nichtdeterminismus muss man auflösen
-> man geht friday soon Kante nur, wenn nicht 3h vergangen auftaucht gleichzeitig und 1 Uhr
-> Kante wenn beide gleichzeitig auftauchen

![_2022-02-24-04-14-29](_resources/_2022-02-24-04-14-29.png)
- alle Transitionen im Rechteck überall 'Nicht-1Am'
- '+' soll ein AND sein

## b)
![_2022-02-24-04-26-43](_resources/_2022-02-24-04-26-43.png)
- Nicht-determinismus in Klammern, weil es auch Nicht-deterministische Automaten außerhalb der Vorlesung gibt. Statecharts können Nicht-determinismus darstellen

![_2022-02-24-04-34-43](_resources/_2022-02-24-04-34-43.png)
- timer -> wait 10ns
- intere und externee Events -> mehr darstellen als bei finite state machines
