![_2022-02-24-08-29-32](_resources/_2022-02-24-08-29-32.png)

# 1
![_2022-02-24-04-56-20](_resources/_2022-02-24-04-56-20.png)
- im Tool gibt es keine Nebenläufigkeit / Parallelismus

![_2022-02-24-04-56-56](_resources/_2022-02-24-04-56-56.png)
- Event E und Variablen X und Y

![_2022-02-24-05-01-27](_resources/_2022-02-24-05-01-27.png)

## c)
![_2022-02-24-05-10-09](_resources/_2022-02-24-05-10-09.png)
- x sollte 5 sein, y sollte 28 sein

![_2022-02-24-05-11-43](_resources/_2022-02-24-05-11-43.png)
- yakindu fürht zuerst 1, dann 2 aus, X ist überschriebener Wert aus B Region

![_2022-02-24-05-13-45](_resources/_2022-02-24-05-13-45.png)

## d)
![_2022-02-24-05-15-03](_resources/_2022-02-24-05-15-03.png)
- Semantik in Theorie und Realität unterscheiden sich
- das ist genau das gleiche bei Nicht-Determinismus, da laberln wir unsere Transitions auch mit 1 und 2. Und wenn beide gleichzeitig ankommen, wird die 1er Kante genommen

# 2
![_2022-02-24-05-25-53](_resources/_2022-02-24-05-25-53.png)

![_2022-02-24-08-13-11](_resources/_2022-02-24-08-13-11.png)

![_2022-02-24-08-24-47](_resources/_2022-02-24-08-24-47.png)

![_2022-02-24-08-26-07](_resources/_2022-02-24-08-26-07.png)
- eher weniger wahrscheinlich klausurrelevant

# 3
## a)
![_2022-02-24-08-42-34](_resources/_2022-02-24-08-42-34.png)
- deutlicher klausurelevanter
- Conditions, Events, Flow Relations
- unsere Tokens sind nach Eingangsbelegung in den Conditions R1, R2 und S, alle anderen sind leer
- **Vorgehen:** zeichne zuerst Conditions mit Kreis, dann Flow Relations anschauen: schauen wann Event GO1 auftaucht, taucht mit G1 und O1 auf (ansonsten sieht man das nicht mehr) -> bedeutet: wenn es nur zwischen G1 und O1 ist, kann man es direkt einzeichen

## b)
![_2022-02-24-08-52-02](_resources/_2022-02-24-08-52-02.png)
- in welchen Conditions kann man gleichzeitig landen? -> Erreichbarkeitsgraph
- das soll Ampel darstellen R ist rot, O ist orange und G ist grün
- verhindern, dass g1 und g2 gleichzeitig Token haben, das würde bedeuten, dass beide Ampeln grün sind

![_2022-02-24-08-55-25](_resources/_2022-02-24-08-55-25.png)
- an R1 kann man nichts machen, denn dazu braucht man in s wieder ein Token

![_2022-02-24-09-00-19](_resources/_2022-02-24-09-00-19.png)
- was wir sehen: {G1, G2} kommt im Erreichbarkeitsgraph nicht vor (nie gleichzeitig aktiv, also ein Token haben) -> unsere Kreuzung ist save
